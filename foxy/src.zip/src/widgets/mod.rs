pub mod palette;
